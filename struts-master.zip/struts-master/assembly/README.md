# Struts 2 Assemblies
This module is used to prepare ZIP archives with different set of JARs, like code source, Javadocs, etc.
It's a part of the release process, it shouldn't be used directly by users. 
