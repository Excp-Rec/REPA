# Struts 2 Apps
These module consists of two example applications, which were built using the Apache Struts project.
One is an old-fashioned Web application and another is a modern REST based single page app.

## Installation
Enter a given folder, either `showcase/` or `rest-showcase/` and start the app using Maven:

```
mvn jetty:run
```

then open your browser at http://localhost:8080 and navigate to a proper context.
