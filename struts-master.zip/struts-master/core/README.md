# Struts 2 Core
This is a core of the Apache Struts framework and all other modules depend on it.
It requires Java 8 at minimum and a Servlet container supporting Java Servlet API 3.1 at least. 

## Installation
Just drop this plugin into `WEB-INF/lib` folder or add it as Maven dependency
