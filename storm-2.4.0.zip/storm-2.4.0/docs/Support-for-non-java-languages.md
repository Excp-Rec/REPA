---
title: Support for Non-Java Languages
layout: documentation
documentation: true
---
* [Scala DSL](https://github.com/velvia/ScalaStorm)
* [JRuby DSL](https://github.com/colinsurprenant/storm-jruby)
* [Clojure DSL](Clojure-DSL.html)
* [io-storm](https://github.com/gphat/io-storm): Perl multilang adapter
