package com.alibaba.fastjson.deserializer.issues3796.bean;





public class ObjectU1_A {
	
	private int a;
	
	private long b;
	
	private int c;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public long getB() {
		return b;
	}

	public void setB(long b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}
}
