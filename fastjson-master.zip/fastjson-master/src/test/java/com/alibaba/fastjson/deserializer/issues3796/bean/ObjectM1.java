package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectM1 {

	
	private int a;

	
	private int b;

	
	private int c;

	
	private int d;

	
	private List<ObjectM1_A> e;

	
	private List<ObjectM1_B> f;

	
	private int g;
	
	private int h;
	
	private int i;
	
	private int j;
	
	private int k;
	
	private boolean l;
	
	private int m;
	
	private int n;

	
	private int o;
	
	private int p;
	
	private boolean q;
	
	private CommonObject r;
	
	private int s;

	
	private long t;

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public List<ObjectM1_A> getE() {
		return e;
	}

	public void setE(List<ObjectM1_A> e) {
		this.e = e;
	}

	public List<ObjectM1_B> getF() {
		return f;
	}

	public void setF(List<ObjectM1_B> f) {
		this.f = f;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	public boolean isL() {
		return l;
	}

	public void setL(boolean l) {
		this.l = l;
	}

	public int getM() {
		return m;
	}

	public void setM(int m) {
		this.m = m;
	}

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	public int getO() {
		return o;
	}

	public void setO(int o) {
		this.o = o;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	public boolean isQ() {
		return q;
	}

	public void setQ(boolean q) {
		this.q = q;
	}

	public CommonObject getR() {
		return r;
	}

	public void setR(CommonObject r) {
		this.r = r;
	}

	public int getS() {
		return s;
	}

	public void setS(int s) {
		this.s = s;
	}

	public long getT() {
		return t;
	}

	public void setT(long t) {
		this.t = t;
	}
}
