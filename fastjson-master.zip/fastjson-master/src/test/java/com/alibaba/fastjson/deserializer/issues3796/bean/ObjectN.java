package com.alibaba.fastjson.deserializer.issues3796.bean;






import java.util.List;


public class ObjectN {

	private List<Long> a;

	private List<Long> b;


	private List<CommonObject3> c;


	private List<CommonObject3> d;


	private List<Long> e;


	private List<String> f;


	private List<Long> g;


	private List<OjectN_A> h;


	private List<CommonObject3> i;


	private List<Long> j;


	private List<String> k;


	private List<CommonObject3> l;

	public List<Long> getA() {
		return a;
	}

	public void setA(List<Long> a) {
		this.a = a;
	}

	public List<Long> getB() {
		return b;
	}

	public void setB(List<Long> b) {
		this.b = b;
	}

	public List<CommonObject3> getC() {
		return c;
	}

	public void setC(List<CommonObject3> c) {
		this.c = c;
	}

	public List<CommonObject3> getD() {
		return d;
	}

	public void setD(List<CommonObject3> d) {
		this.d = d;
	}

	public List<Long> getE() {
		return e;
	}

	public void setE(List<Long> e) {
		this.e = e;
	}

	public List<String> getF() {
		return f;
	}

	public void setF(List<String> f) {
		this.f = f;
	}

	public List<Long> getG() {
		return g;
	}

	public void setG(List<Long> g) {
		this.g = g;
	}

	public List<OjectN_A> getH() {
		return h;
	}

	public void setH(List<OjectN_A> h) {
		this.h = h;
	}

	public List<CommonObject3> getI() {
		return i;
	}

	public void setI(List<CommonObject3> i) {
		this.i = i;
	}

	public List<Long> getJ() {
		return j;
	}

	public void setJ(List<Long> j) {
		this.j = j;
	}

	public List<String> getK() {
		return k;
	}

	public void setK(List<String> k) {
		this.k = k;
	}

	public List<CommonObject3> getL() {
		return l;
	}

	public void setL(List<CommonObject3> l) {
		this.l = l;
	}
}
