package com.alibaba.fastjson.deserializer.issues3796.bean;





import java.util.List;


public class ObjectY {
	
	private List<ObjectY_A> a;

	
	private long b;

	
	private int c = 0;

	
	private boolean d = false;

	
	private int e = -1;

	
	private int f = 0;

	
	private int g = 0;

	

	
	private int h;
	
	private boolean i =false;
	
	private List<Integer> j;
	
	private List<Integer> k;

	public List<ObjectY_A> getA() {
		return a;
	}

	public void setA(List<ObjectY_A> a) {
		this.a = a;
	}

	public long getB() {
		return b;
	}

	public void setB(long b) {
		this.b = b;
	}

	public int getC() {
		return c;
	}

	public void setC(int c) {
		this.c = c;
	}

	public boolean isD() {
		return d;
	}

	public void setD(boolean d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getH() {
		return h;
	}

	public void setH(int h) {
		this.h = h;
	}

	public boolean isI() {
		return i;
	}

	public void setI(boolean i) {
		this.i = i;
	}

	public List<Integer> getJ() {
		return j;
	}

	public void setJ(List<Integer> j) {
		this.j = j;
	}

	public List<Integer> getK() {
		return k;
	}

	public void setK(List<Integer> k) {
		this.k = k;
	}
}
