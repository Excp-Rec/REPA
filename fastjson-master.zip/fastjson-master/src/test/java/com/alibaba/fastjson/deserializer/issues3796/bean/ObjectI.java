package com.alibaba.fastjson.deserializer.issues3796.bean;




import java.util.List;


public class ObjectI {
	
	private String a;
	
	private int b;
	
	private long c;
	
	private int d;
	
	private int e;
	
	private int f;

	
	private int g;

	
	private List<ObjectI_A> h;

	
	private List<Integer> i;

	
	private int j;

	private int k;
	private int l;

	public String getA() {
		return a;
	}

	public void setA(String a) {
		this.a = a;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public long getC() {
		return c;
	}

	public void setC(long c) {
		this.c = c;
	}

	public int getD() {
		return d;
	}

	public void setD(int d) {
		this.d = d;
	}

	public int getE() {
		return e;
	}

	public void setE(int e) {
		this.e = e;
	}

	public int getF() {
		return f;
	}

	public void setF(int f) {
		this.f = f;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public List<ObjectI_A> getH() {
		return h;
	}

	public void setH(List<ObjectI_A> h) {
		this.h = h;
	}

	public List<Integer> getI() {
		return i;
	}

	public void setI(List<Integer> i) {
		this.i = i;
	}

	public int getJ() {
		return j;
	}

	public void setJ(int j) {
		this.j = j;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}
}
