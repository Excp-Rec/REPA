---
name: Discussion
about: Start a discussion for Dubbo
title: ''
labels: type/discussion
assignees: ''
---

<!-- If you need to report a security issue please visit https://github.com/apache/dubbo/security/policy -->

<!-- For all design discussions please continue. -->
