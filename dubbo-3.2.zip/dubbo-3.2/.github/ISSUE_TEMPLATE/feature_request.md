---
name: Feature Request
about: Create a Feature Request for Dubbo
title: ''
labels: type/feature
assignees: ''

---
<!-- If you need to report a security issue please visit https://github.com/apache/dubbo/security/policy -->

- [ ] I have searched the [issues](https://github.com/apache/dubbo/issues) of this repository and believe that this is not a duplicate.
- [ ] I have searched the [release notes](https://github.com/apache/dubbo/releases) of this repository and believe that this is not a duplicate.

## Describe the feature
<!-- Please also discuss possible business value -->

