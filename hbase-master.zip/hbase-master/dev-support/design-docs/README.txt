This directory hosts design docs and proposals. Add here final
or near-final writeups so they are easy to find and part of
the code base.

Be warned that final delivery may not be a perfect reflection
of what is captured at design time; implementation bends as
it encounters hurdles not conceptualized at design-time.

The effort at capturing all design in a single directory ratherthan spread
about JIRA as attachments was begun in September of 2017.
