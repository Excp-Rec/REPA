package com.alibaba.druid.sql.ast.statement;

import com.alibaba.druid.sql.ast.SQLStatement;

public interface SQLLockTableStatement extends SQLStatement {
}
