package com.alibaba.druid.sql.ast;

public enum ClusteringType {
    Range,
    Hash
}
