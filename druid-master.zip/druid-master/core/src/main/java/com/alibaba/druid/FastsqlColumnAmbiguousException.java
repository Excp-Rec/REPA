package com.alibaba.druid;

public class FastsqlColumnAmbiguousException extends FastsqlException {
    public FastsqlColumnAmbiguousException() {
    }

    public FastsqlColumnAmbiguousException(String msg) {
        super(msg);
    }
}
